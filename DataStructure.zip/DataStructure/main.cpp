//
//  main.cpp
//  DataStructure
//
//  Created by Janany Thillainathan on 27/05/2020.
//  Copyright © 2020 Janany Thillainathan. All rights reserved.
// the class identifies the members of cash register.
// the class identifies the members of dispenser.

#include <iostream>
#include "juiceMachine.h"

using namespace std;

int cashRegister::getCurrentBalance() const
{
    return cashOnHand;
}

void cashRegister::acceptAmount(int amountIn)
{
    cashOnHand = cashOnHand + amountIn;
}

cashRegister::cashRegister(int cashIn)
{
    if (cashIn >=0)
        cashOnHand = cashIn;
    else
        cashOnHand = 700;
}

int dispenserType::getNoOFItems() const
{
    return numberOfItems;
}

int dispenserType::getCost() const
{
    return cost;
}

void dispenserType::makeIncome()
{
    numberOfItems--;
}

dispenserType::dispenserType(int setNoOfItems, int setCost)
{
    if (setNoOfItems >=0)
        numberOfItems = setNoOfItems;
    else
        numberOfItems = 100;
    if (setCost >=0)
        cost = setCost;
    else
        cost = 100;
}


void showSelection();
void sellProduct(dispenserType& product,
                 cashRegister& pCounter);

int main()
{
    cashRegister counter;
    dispenserType lychee(80, 50);
    dispenserType kiwi (45, 95);
    dispenserType mangolassi (70, 90);
    dispenserType pineapple (100, 75);
    
    int choice; //variable to hold the selection
    
    showSelection();
    cin >> choice;
    
    while (choice != 0)
    {
        switch (choice)
        {
            case 1:
                sellProduct(lychee, counter);
                break;
            case 2:sellProduct(kiwi, counter);
                break;
            case 3:sellProduct(mangolassi, counter);
                break;
            case 4:sellProduct(pineapple, counter);
                break;
            default:
                cout << "Wrong Selection!" << endl;
        }//end the switch
        showSelection();
        cin >> choice;
    }//end while loop
    
    return 0;
}// end main function

void showSelection ()
{
    cout << "*** Welcome to Janu's Juice Shop ***" << endl;
    cout << "To select an item, Please Enter " << endl;
    cout << "1 for lychee juice" << endl;
    cout << "2 for kiwi juice" << endl;
    cout << "3 for mangolassi juice" << endl;
    cout << "4 for pineapple juice" << endl;
    cout << "10 to exit" << endl;
}//end showSelection

void sellProduct(dispenserType& product,
                 cashRegister& pCounter)
{
    int amount; //variable to hold the entered amount
    int amount2; //variable to hold the extra amount required
    
    if (product.getNoOFItems() > 0) //if the dispenser not empty
    {
        cout << "Please deposit " << product.getCost()
        << " pounds" << endl;
        cin >> amount;
        
        if (amount < product.getCost())
        {
            cout << "Please deposit another one"
            << product.getCost() - amount
            << " pounds" << endl;
            cin >> amount2;
            amount = amount + amount2;
        }
        
        if (amount >= product.getCost())
        {
            pCounter.acceptAmount(amount);
            product.makeIncome();
            cout << "Please Collect your item at the counter and "
            << "Enjoy! ...Have a Nice day!" << endl;
        }
        else
            cout << "Sorry, The amount is not enough."
            << "Collect what you deposited." << endl;
        
        cout << "*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*"
        << endl << endl;
    }
    else
        cout << "Really Sorry, this item is sold out!" << endl;
        
}//end sellProduct
                
        
    

