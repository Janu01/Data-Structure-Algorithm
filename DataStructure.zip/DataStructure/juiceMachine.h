//
//  juiceMachine.h
//  DataStructure
//
//  Created by Janany Thillainathan on 30/05/2020.
//  Copyright © 2020 Janany Thillainathan. All rights reserved.
//

#ifndef juiceMachine_h
#define juiceMachine_h


#endif /* juiceMachine_h */

#include <iostream>




class cashRegister
{
public:
    int getCurrentBalance() const; //Function to recognise the current amount in cash
    
    void acceptAmount(int amountIn); //Function to receive the deposited amount from customer
    
    cashRegister(int cashIn = 700); //Constructor which sets the cash in the register to a verified amount
    
private:
    int cashOnHand; //Variable to input the cash in the register
};

class dispenserType
{
public:
    int getNoOFItems() const; // Function to view the number of items in the machine
    
    int getCost() const; // Function to show the cost of the items
    
    void makeIncome(); // Function to reduce the number of items by 1
    
    dispenserType (int setNoOfItems = 100, int setCost = 100); //Constructor which sets the number and cost of the items in dispenser to the values expected from user.
private:
    int numberOfItems; //variable to store the number of items in the dispenser
    int cost; // variable to store the cost of an item
};
